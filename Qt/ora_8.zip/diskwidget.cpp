#include "diskwidget.h"

DiskWidget::DiskWidget(int count, int id, QWidget *parent) : QWidget{parent}
{
    double ratio = double(id + 1) / count;
    setFixedSize(s_iMAX_WIDTH * ratio, s_iHEIGHT);
    // setting the background color of the disk
    QPalette pal = palette();
    // WINDOW sets the background
    pal.setColor(QPalette::ColorRole::Window,
                 QColor(ratio * 255, (1 - ratio) * 127, int(3 * ratio) % 255));
    setPalette(pal);
    setAutoFillBackground(true);
}
