#include "towerwidget.h"
//
#include "diskwidget.h"
#include "hanoimodel.h"

TowerWidget::TowerWidget(HanoiModel *model, int id, QWidget *parent)
    : QWidget{parent}, m_iId(id), m_pModel(model)
{
    // direction of filling the layout
    m_qMainLayout = new QBoxLayout(QBoxLayout::BottomToTop, this);
    setLayout(m_qMainLayout);
    // eliminate space between widgets
    m_qMainLayout->setSpacing(0);
    connect(m_pModel, &HanoiModel::boardUpdate, this, &TowerWidget::updateTower);
    // keep the width of the widget regardless of its disks
    setMinimumWidth(DiskWidget::s_iMAX_WIDTH);
}

void TowerWidget::updateTower()
{
    // remove all layout items: stretch(spacerItem) too,
    // which is not a widget
    while (m_qMainLayout->count() != 0) {
        QLayoutItem *item = m_qMainLayout->itemAt(0);
        if (QWidget *w = item->widget()) {
            delete w;
        }
        m_qMainLayout->removeItem(item);
    }
    QVector<int> disks = m_pModel->disksAt(m_iId);
    int diskCount	   = m_pModel->diskCount();
    // iterate over the disk id-s in a reversed order
    for (auto it = disks.rbegin(); it != disks.rend(); ++it) {
        m_qMainLayout->addWidget(new DiskWidget(diskCount, *it, this), 0,
                                 // align disk to the center
                                 Qt::AlignCenter | Qt::AlignBottom);
    }
    // add stetch to keep the disks down
    m_qMainLayout->addStretch(diskCount - disks.size());
}
