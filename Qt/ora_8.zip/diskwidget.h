#ifndef DISKWIDGET_H
#define DISKWIDGET_H

#include <QWidget>

class DiskWidget : public QWidget
{
    Q_OBJECT
  public:
    static const int s_iMAX_WIDTH = 240, s_iHEIGHT = 30;
    explicit DiskWidget(int count, int id, QWidget *parent = nullptr);
};

#endif // DISKWIDGET_H
