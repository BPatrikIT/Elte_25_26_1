#include "mainwindow.h"

//
#include "persistence.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
  m_pSpreadsheet = new Spreadsheet(new persistence(this), this);
  setCentralWidget(m_pSpreadsheet);
}

MainWindow::~MainWindow() {}
