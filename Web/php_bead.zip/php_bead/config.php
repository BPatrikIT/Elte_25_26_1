
<?php
session_start();
define('DATA_DIR', __DIR__ . '/data');

function load_json($file) {
    $path = DATA_DIR . '/' . $file;
    if (!file_exists($path)) return [];
    return json_decode(file_get_contents($path), true);
}

function save_json($file, $data) {
    file_put_contents(DATA_DIR . '/' . $file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function is_logged_in() {
    return isset($_SESSION['user']);
}

function is_admin() {
    return is_logged_in() && $_SESSION['user']['is_admin'];
}

$CATEGORIES = [
    1 => "Helyi kis projekt",
    2 => "Helyi nagy projekt",
    3 => "Esélyteremtő Budapest",
    4 => "Zöld Budapest"
];
?>
