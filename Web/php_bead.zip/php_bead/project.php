
<?php
require 'config.php';
$projects = load_json('projects.json');
$id = $_GET['id'] ?? null;

foreach ($projects as $p) {
    if ($p['id'] == $id) {
        if ($p['status'] !== 'approved' &&
            (!is_logged_in() || ($_SESSION['user']['id'] != $p['owner'] && !is_admin()))
        ) {
            header('Location: index.php'); exit;
        }
        ?>
        <h1><?= htmlspecialchars($p['title']) ?></h1>
        <p><strong>Kategória:</strong> <?= $CATEGORIES[$p['category']] ?></p>
        <p><?= nl2br(htmlspecialchars($p['description'])) ?></p>
        <?php
        exit;
    }
}
header('Location: index.php');
