
<?php
require 'config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (strlen($_POST['password']) < 8) {
        $error = "A jelszó legalább 8 karakter";
    } else {
        $users = load_json('users.json');
        foreach ($users as $u) {
            if ($u['username']===$_POST['username']) {
                $error = "A felhasználónév már létezik";
                break;
            }
        }
        if (!$error) {
            $users[] = [
                "id" => count($users)+1,
                "username" => $_POST['username'],
                "email" => $_POST['email'],
                "password" => password_hash($_POST['password'], PASSWORD_DEFAULT),
                "is_admin" => false
            ];
            save_json('users.json', $users);
            header('Location: login.php'); exit;
        }
    }
}
?>
<h1>Regisztráció</h1>
<form method="post">
Felhasználónév: <input name="username"><br>
Email: <input name="email"><br>
Jelszó: <input type="password" name="password"><br>
<button>Regisztráció</button>
</form>
<p style="color:red"><?= $error ?></p>
