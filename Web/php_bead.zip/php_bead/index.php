
<?php
require 'config.php';
$projects = load_json('projects.json');
$selected = $_GET['category'] ?? 'all';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Budapesti Közösségi Költségvetés</title>
</head>
<body>
<h1>Közzétett projektek</h1>

<form method="get">
<select name="category" onchange="this.form.submit()">
    <option value="all">Összes kategória</option>
    <?php foreach ($CATEGORIES as $id => $name): ?>
        <option value="<?= $id ?>" <?= $selected==$id?'selected':'' ?>><?= $name ?></option>
    <?php endforeach; ?>
</select>
</form>

<?php foreach ($projects as $p): ?>
    <?php
        if ($p['status'] !== 'approved') continue;
        if ($selected !== 'all' && $p['category'] != $selected) continue;
    ?>
    <div style="border:1px solid #ccc; padding:10px; margin:10px 0;">
        <h3>
            <a href="project.php?id=<?= $p['id'] ?>">
                <?= htmlspecialchars($p['title']) ?>
            </a>
        </h3>
        <p>Kategória: <?= $CATEGORIES[$p['category']] ?></p>
        <p>Szavazatok száma: <?= $p['votes'] ?></p>
    </div>
<?php endforeach; ?>

<?php if (is_logged_in()): ?>
<p>Bejelentkezve: <?= $_SESSION['user']['username'] ?> | <a href="logout.php">Kijelentkezés</a></p>
<?php else: ?>
<a href="login.php">Bejelentkezés</a> | <a href="register.php">Regisztráció</a>
<?php endif; ?>

</body>
</html>
