
<?php
require 'config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $users = load_json('users.json');
    foreach ($users as $u) {
        if ($u['username']===$_POST['username']
            && password_verify($_POST['password'], $u['password'])) {
            $_SESSION['user'] = $u;
            header('Location: index.php'); exit;
        }
    }
    $error = "Hibás felhasználónév vagy jelszó";
}
?>
<h1>Bejelentkezés</h1>
<form method="post">
Felhasználónév: <input name="username"><br>
Jelszó: <input type="password" name="password"><br>
<button>Belépés</button>
</form>
<p style="color:red"><?= $error ?></p>
